## 0.3.0

- Added blur option for background blur
- Attempted a fix for missed dart formatting

## 0.2.1

- Minor fixes in README file.
- Added dartdoc strings.
- Fixed most issues to follow dart guidelines.

## 0.2.0

-   Added support for other platforms.

## 0.1.0-nullsafety-2

-   Downgraded dart and Flutter SDK version.

## 0.1.0-nullsafety-1

-   Readme fixed.

## 0.1.0-nullsafety-0

-   Implemented Sound Null Safety 💪

## 0.0.1

-   Inported code from the parent package, https://github.com/mmcc007/modal_progress_hud