#import <Flutter/Flutter.h>

@interface ModalProgressHudNsnPlugin : NSObject<FlutterPlugin>
@end
